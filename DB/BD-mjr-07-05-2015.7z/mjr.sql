-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 07-Maio-2015 às 10:56
-- Versão do servidor: 5.5.34
-- versão do PHP: 5.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `mjr`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos`
--

CREATE TABLE IF NOT EXISTS `eventos` (
  `ID_Evento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(50) DEFAULT NULL,
  `Data` date DEFAULT NULL,
  `Valor` decimal(8,2) unsigned DEFAULT NULL,
  `Local` varchar(100) DEFAULT NULL,
  `Obs` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID_Evento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `jovem`
--

CREATE TABLE IF NOT EXISTS `jovem` (
  `ID_Jovem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `FlgExcluido` tinyint(1) NOT NULL DEFAULT '0',
  `Nome` varchar(100) DEFAULT NULL,
  `DatNasc` date DEFAULT NULL,
  `NomePai` varchar(100) DEFAULT NULL,
  `NomeMae` varchar(100) DEFAULT NULL,
  `Endereco` varchar(100) DEFAULT NULL,
  `Telefone` varchar(15) DEFAULT NULL,
  `Celular` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `RG` varchar(15) DEFAULT NULL,
  `CPF` varchar(11) DEFAULT NULL,
  `Obs` varchar(200) DEFAULT NULL,
  `ID_Sede` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID_Jovem`),
  KEY `ID_Sede` (`ID_Sede`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Extraindo dados da tabela `jovem`
--

INSERT INTO `jovem` (`ID_Jovem`, `FlgExcluido`, `Nome`, `DatNasc`, `NomePai`, `NomeMae`, `Endereco`, `Telefone`, `Celular`, `Email`, `RG`, `CPF`, `Obs`, `ID_Sede`) VALUES
(1, 0, 'Robson', '1994-10-14', 'PAI', 'MAE', 'Rua dosTrogloditas, 155, Bairro das Falácias', '(31)3212-3212', '(31)9999-9999', 'bol@bol.com', 'MG123456789', '', 'Observações do cadastro', 1),
(2, 0, 'Yitzhak', '1994-10-14', 'PAI', 'MAE', 'Rua dosTrogloditas, 155, Bairro das Falácias', '(31)3212-3212', '(31)9999-9999', 'bol@bol.com', 'MG123456789', '12345678900', 'Observações do cadastro', 2),
(3, 0, 'Vinicius', '1994-10-14', 'PAI', 'MAE', 'Rua dosTrogloditas, 155, Bairro das Falácias', '(31)3212-3212', '(31)9999-9999', 'bol@bol.com', 'MG123456789', '12345678900', 'Observações do cadastro', 2),
(4, 0, 'Camila', '1994-10-14', 'PAI', 'MAE', 'Rua dosTrogloditas, 155, Bairro das Falácias', '(31)3212-3212', '(31)9999-9999', 'bol@bol.com', 'MG123456789', '', 'Observações do cadastro', 9),
(5, 0, 'Yitzhak', '1994-10-14', 'PAI', 'MAE', 'Rua dosTrogloditas, 155, Bairro das Falácias', '(31)3212-3212', '(31)9999-9999', 'bol@bol.com', 'MG123456789', '12345678900', 'Observações do cadastro', 1),
(6, 0, 'Mateus', '1994-10-14', 'PAI', 'MAE', 'Rua dosTrogloditas, 155, Bairro das Falácias', '(31)3212-3212', '(31)9999-9999', 'bol@bol.com', 'MG123456789', '12345678900', 'Observações do cadastro', 2),
(9, 0, 'Abel', '1940-07-18', 'Adão', 'Eva', 'Bairro Paraiso', '(31)3212-3212', '(31)9999-9999', 'bol@bol.com', 'MG123456789', '', '', 3),
(21, 0, 'zebulom', '1967-12-31', 'PAI', 'MAE', 'algum lugar em santa luzia', '(31)3212-3212', '(31)3270-5000', 'zebulom@soeletem.com', 'MG123456789', 'ele não é b', 'eu gosto de coelhos!', 2),
(22, 0, 'Daniele', '1948-01-01', 'Papai', 'Mamae', 'Centro BH', '(31)3131-3131', '(31)9797-9797', 'lider@teste', 'MG123456789', '46887468468', 'estou com sono já', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `jovemevento`
--

CREATE TABLE IF NOT EXISTS `jovemevento` (
  `ID_Jovem` int(10) unsigned NOT NULL,
  `ID_Evento` int(10) unsigned NOT NULL,
  `FlgPago` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID_Jovem`,`ID_Evento`),
  KEY `ID_Evento` (`ID_Evento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `jovemministerio`
--

CREATE TABLE IF NOT EXISTS `jovemministerio` (
  `ID_Jovem` int(10) unsigned NOT NULL,
  `ID_Minist` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ID_Jovem`,`ID_Minist`),
  KEY `ID_Minist` (`ID_Minist`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `jovemministerio`
--

INSERT INTO `jovemministerio` (`ID_Jovem`, `ID_Minist`) VALUES
(2, 1),
(3, 1),
(4, 1),
(1, 2),
(3, 2),
(5, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `ministerio`
--

CREATE TABLE IF NOT EXISTS `ministerio` (
  `ID_Minist` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `FlgExcluido` tinyint(1) NOT NULL DEFAULT '0',
  `Nome` varchar(50) DEFAULT NULL,
  `ID_Lider` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID_Minist`),
  KEY `ID_Lider` (`ID_Lider`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `ministerio`
--

INSERT INTO `ministerio` (`ID_Minist`, `FlgExcluido`, `Nome`, `ID_Lider`) VALUES
(1, 0, 'Street Dance', 1),
(2, 0, 'Teatro - Alfa e Omega', 1),
(3, 0, 'Coreografia  - Visão de Águia', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sede`
--

CREATE TABLE IF NOT EXISTS `sede` (
  `ID_Sede` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `FlgExcluido` tinyint(1) NOT NULL DEFAULT '0',
  `Nome` varchar(50) DEFAULT NULL,
  `Endereco` varchar(100) DEFAULT NULL,
  `Obs` varchar(200) DEFAULT NULL,
  `ID_Lider` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ID_Sede`),
  KEY `ID_Lider` (`ID_Lider`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Extraindo dados da tabela `sede`
--

INSERT INTO `sede` (`ID_Sede`, `FlgExcluido`, `Nome`, `Endereco`, `Obs`, `ID_Lider`) VALUES
(1, 0, 'Sede BH', 'Av. Dos Andradas, 1005 E 981 Centro - Belo Horizonte', 'Sede Estadual', 22),
(2, 0, 'Bairro São Paulo', 'Av. Cristiano Machado, 5554 São Paulo - Belo Horizonte - Mg', '', 5),
(3, 0, 'Acaiaca', 'Av. Afonso Pena, 867 Edifício Acaiaca Centro - Belo Horizonte - Mg', '', 1),
(4, 0, 'Independência', 'R: Maria Antonieta, 130 (esquina C/ Flor De Pitangueira) Independência - Belo Horizonte - Mg', '', 1),
(5, 0, 'Ribeirão Das Neves', 'Rua José Maria Alkimim, 90 Centro - Ribeirão Das Neves - Mg', '', 4),
(9, 0, 'Venda Nova', 'Rua Padre Pedro Pinto, 2250 Venda Nova - Belo Horizonte - Mg', '', 22);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `nmusuario` varchar(45) DEFAULT NULL,
  `dssenha` varchar(45) DEFAULT NULL,
  `fgstatus` varchar(45) DEFAULT NULL,
  `login` varchar(45) DEFAULT NULL,
  `perfil` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`idusuario`, `nmusuario`, `dssenha`, `fgstatus`, `login`, `perfil`) VALUES
(1, 'Fulano de Teste', 'c4ca4238a0b923820dcc509a6f75849b', 'A', '1', 'admin'),
(3, 'Administrador', 'e3afed0047b08059d0fada10f400c1e5', 'A', 'admin', 'admin');

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `jovem`
--
ALTER TABLE `jovem`
  ADD CONSTRAINT `jovem_ibfk_1` FOREIGN KEY (`ID_Sede`) REFERENCES `sede` (`ID_Sede`);

--
-- Limitadores para a tabela `jovemevento`
--
ALTER TABLE `jovemevento`
  ADD CONSTRAINT `jovemevento_ibfk_1` FOREIGN KEY (`ID_Jovem`) REFERENCES `jovem` (`ID_Jovem`),
  ADD CONSTRAINT `jovemevento_ibfk_2` FOREIGN KEY (`ID_Evento`) REFERENCES `jovem` (`ID_Jovem`);

--
-- Limitadores para a tabela `jovemministerio`
--
ALTER TABLE `jovemministerio`
  ADD CONSTRAINT `jovemministerio_ibfk_1` FOREIGN KEY (`ID_Jovem`) REFERENCES `jovem` (`ID_Jovem`),
  ADD CONSTRAINT `jovemministerio_ibfk_2` FOREIGN KEY (`ID_Minist`) REFERENCES `ministerio` (`ID_Minist`);

--
-- Limitadores para a tabela `ministerio`
--
ALTER TABLE `ministerio`
  ADD CONSTRAINT `ministerio_ibfk_1` FOREIGN KEY (`ID_Lider`) REFERENCES `jovem` (`ID_Jovem`);

--
-- Limitadores para a tabela `sede`
--
ALTER TABLE `sede`
  ADD CONSTRAINT `sede_ibfk_1` FOREIGN KEY (`ID_Lider`) REFERENCES `jovem` (`ID_Jovem`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
